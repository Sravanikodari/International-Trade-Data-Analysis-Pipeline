
-- HS codes ranked by total value

WITH hsn_totals AS (
    SELECT
        hs_code,
        SUM(total_value_inr) AS total_value_inr
    FROM trade_shipments
    GROUP BY hs_code
),

ranked AS (
    SELECT
        hs_code,
        total_value_inr,
        total_value_inr * 1.0 / SUM(total_value_inr) OVER () AS share_of_total,
        ROW_NUMBER() OVER (ORDER BY total_value_inr DESC) AS rn
    FROM hsn_totals
)

SELECT *
FROM ranked
ORDER BY total_value_inr DESC;