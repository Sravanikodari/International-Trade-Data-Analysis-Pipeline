
-- Capacity / spec vs volume & landed cost

SELECT
    capacity_spec,
    SUM(COALESCE(qty, quantity))          AS total_units,
    SUM(grand_total)                      AS total_grand_total_inr,
    AVG(landed_cost_per_unit)             AS avg_landed_cost_per_unit
FROM trade_shipments
WHERE capacity_spec IS NOT NULL
GROUP BY capacity_spec
ORDER BY total_units DESC;