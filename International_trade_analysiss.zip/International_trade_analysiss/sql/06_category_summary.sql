
-- Category / Subcategory level summary for dashboard

SELECT
    category,
    subcategory,
    COUNT(*)                               AS shipment_count,
    SUM(total_value_inr)                   AS total_value_inr,
    SUM(duty_paid_inr)                     AS total_duty_paid_inr,
    SUM(grand_total)                       AS total_grand_total_inr,
    AVG(landed_cost_per_unit)              AS avg_landed_cost_per_unit
FROM trade_shipments
GROUP BY category, subcategory
ORDER BY total_value_inr DESC;