
-- Model-level quantity vs unit price per year

SELECT
    model_code,
    year,
    SUM(COALESCE(qty, quantity))      AS total_units,
    AVG(unit_price_inr)               AS avg_unit_price_inr,
    AVG(orig_unit_price)              AS avg_foreign_unit_price,
    COUNT(*)                          AS transaction_count
FROM trade_shipments
WHERE model_code IS NOT NULL
GROUP BY model_code, year
ORDER BY year, model_code;