
-- Duty percentage anomalies (±2 standard deviations), SQLite-compatible (no SQRT/POWER)

WITH base AS (
    SELECT
        *,
        duty_paid_inr * 1.0 / NULLIF(total_value_inr, 0.0) AS duty_percent
    FROM trade_shipments
),

stats AS (
    SELECT
        AVG(duty_percent) AS avg_dp,
        AVG(duty_percent * duty_percent) AS avg_sq
    FROM base
    WHERE duty_percent IS NOT NULL
),

scored AS (
    SELECT
        b.*,
        b.duty_percent,
        s.avg_dp,
        s.avg_sq,
        (s.avg_sq - s.avg_dp * s.avg_dp) AS variance
    FROM base b
    CROSS JOIN stats s
)

SELECT
    *,
    CASE
        WHEN duty_percent IS NOT NULL
             AND variance > 0
             AND ( (duty_percent - avg_dp) * (duty_percent - avg_dp) ) > 4 * variance
        THEN 1
        ELSE 0
    END AS duty_anomaly_flag
FROM scored
ORDER BY duty_anomaly_flag DESC, duty_percent DESC;